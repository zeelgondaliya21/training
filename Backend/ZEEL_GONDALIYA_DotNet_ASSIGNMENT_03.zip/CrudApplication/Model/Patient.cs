﻿namespace CrudApplication.Model
{
    public class Patient
    {
        public int patient_id { get; set; } = default!;
        public string firstname { get; set; } = null;
        public string lastname { get; set; } = null;
        public string middlename { get; set; } = null;
        public string dob { get; set; } = null;
        public int gender_id { get; set; } = default!;

    }
}
